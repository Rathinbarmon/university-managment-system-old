@extends('layout') 
	
	@section('content')
		Setting
	@endsection 