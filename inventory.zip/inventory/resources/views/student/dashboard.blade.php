 @extends('student_layout')
 @section('content')
 
        <div class="content-wrapper">
         
         Wel come
          
        </div>
        
      
 
 @endsection