 @extends('layout')
 @section('content') 
 
  <div class="container-scroller">
    <div class="container-fluid page-body-wrapper">
      <div class="row">
        <div class="content-wrapper full-page-wrapper d-flex align-items-center auth-pages">
          <div class="card col-lg-12 ">
            <div class="card-body ">
              <h3 class="card-title text-left ">Select Semester</h3> 
				
			 
			  
			  
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
      </div>
      <!-- row ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div> 
 @endsection