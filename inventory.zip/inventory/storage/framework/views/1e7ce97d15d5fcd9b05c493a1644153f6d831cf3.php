 
 <?php $__env->startSection('content'); ?>
 
        <div class="content-wrapper">
         
         Wel come
          
        </div>
        
      
 
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('student_layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>