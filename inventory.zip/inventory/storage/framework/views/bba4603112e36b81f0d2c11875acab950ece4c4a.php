 
 <?php $__env->startSection('content'); ?>
 	
<div class="row-fluid sortable">
	<div class="box ">
		<div class="box-header">
 			<div class="box-icon">
				<a href="#" class="btn-setting"><i class="halflings-icon wrench"></i></a>
				<a href="#" class="btn-minimize"><i class="halflings-icon chevron-up"></i></a>
				<a href="#" class="btn-close"><i class="halflings-icon remove"></i></a>
			</div>
		</div>
		<p>
		 <?php
			$message=Session::get('message');
			if($message){
				echo $message;
				Session::put('message',null);
			}
		 ?>
		 </p>
		<div class="box-content">
			<table class="table">
				  <thead>
					  <tr>
						  <th> Id</th>
						  <th> Name</th>
						  <th>F. Name</th>
						  <th>M. Name</th>
						  <th>Number</th>
						  <th>Address</th>
						  <th>Image</th>
						  <th>Pass</th>
						  <th>Dep</th>
						  <th>Ac year</th>
						  <th>Action</th>                                          
					  </tr>
				  </thead>   
				  <tbody>  
					<?php $__currentLoopData = $ece_student_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ece_student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
						<tr>
							<td class="center"><?php echo e($ece_student->student_id); ?></td>
							<td class="center"><?php echo e($ece_student->student_name); ?></td>
							<td class="center"><?php echo e($ece_student->student_fathersname); ?></td> 
							<td class="center"><?php echo e($ece_student->student_mathersname); ?></td> 
							<td class="center"><?php echo e($ece_student->student_phone); ?></td> 
							<td class="center"><?php echo e($ece_student->student_address); ?></td> 
							<td class="center">
							<img src="<?php echo e($ece_student->student_image); ?>" alt="" />
							
							</td> 
							<td class="center"><?php echo e($ece_student->student_password); ?></td> 
							<td class="center"> 
							 
								<?php if($ece_student->student_department==1): ?>
								<span><?php echo e('CSE'); ?></span>
								<?php elseif($ece_student->student_department==2): ?>
								<span><?php echo e('EEE'); ?></span>
								<?php elseif($ece_student->student_department==3): ?>
								<span><?php echo e('ECE'); ?></span>
								<?php elseif($ece_student->student_department==4): ?>
								<span><?php echo e('BBA'); ?></span>
								<?php elseif($ece_student->student_department==5): ?>
								<span><?php echo e('MBA'); ?></span>
								<?php endif; ?>
							</td> 
							<td class="center"><?php echo e($ece_student->student_addmissionyear); ?></td> 
							 
						</tr>   
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>		
				  </tbody>
			 </table>   
		</div>
	</div>  
</div> 
	
 
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>